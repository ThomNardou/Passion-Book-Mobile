let books = [
  {
    id: 11,
    title: "monster",
    category: "manga",
    nbrPages: 1200,
    link: "https://example.com/",
    summary: "A manga about philosophy and nihilism",
    writer: "idk",
    publisherName: "idk",
    publishingYear: 1980,
    averageRating: 5,
    comments: "???",
    coverImage: "https://th.bing.com/th/id/R.f999471f51eab473baa6fe5cf40a7f32?rik=CACwXQt6ldAzHQ&pid=ImgRaw&r=0"
  },
  {
    id: 1,
    title: "L'affaire Charles Dexter Ward",
    category: "short_novel",
    nbrPages: 300,
    link: "https://example.com/",
    summary: "A man become crazy and his family want to help him",
    writer: "H.P Lovecraft",
    publisherName: "J'ai lu",
    publishingYear: 1941,
    averageRating: 7.6,
    comments: "???",
    coverImage: "https://2.bp.blogspot.com/-PXvELHryl4s/V7NmWWOG_DI/AAAAAAAAAzA/u-W2uKmHXVwMVZ_F6eYufsSdr361q06zQCLcB/s1600/AffaireCharlesDexterWard.jpg"
  },
  {
    id: 2,
    title: "Le signe des quatres",
    category: "short_novel",
    nbrPages: 120,
    link: "https://example.com/",
    summary: "Sherlock Holmes is investing",
    writer: "Sir Arthur Conan Doyle",
    publisherName: "Librio",
    publishingYear: 1980,
    averageRating: 5,
    comments: "???",
    coverImage: "https://th.bing.com/th/id/R.f999471f51eab473baa6fe5cf40a7f32?rik=CACwXQt6ldAzHQ&pid=ImgRaw&r=0"
  },
  {
    id: 10,
    title: "L'art de la guerre",
    category: "book",
    nbrPages: 170,
    link: "https://example.com/",
    summary: "How to defeat his enemy",
    writer: "Sun Tzu",
    publisherName: "???",
    publishingYear: 890,
    averageRating: 4.5,
    comments: "???",
    coverImage: "https://th.bing.com/th/id/R.47f2f234b979e69ae71cefb32c768bc2?rik=sURF7fkPdAtjdw&pid=ImgRaw&r=0"
  },
];

export { books }